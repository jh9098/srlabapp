from typing import Generic, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    success: bool = True
    message: str = "ok"
    data: T | None = None
    error_code: str | None = None


class ErrorResponse(ApiResponse[None]):
    success: bool = False
    data: None = None
